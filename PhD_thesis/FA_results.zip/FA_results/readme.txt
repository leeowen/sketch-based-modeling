In the "evaluation-ced" folder: 
    We provide inner-pupil errors over 300W dataset of our method and other current methods: SDM, ERT, LBF.
    We also provide a function for drawing cumulative error distribution (CED) curves

In the "ibug" folder: 
    We provide the results of face alignment over main part of the chanllenging 300W-IBUG dataset,including:
    1. Images  with detected landmarks
    2. inner-pupil errors per face
    3. inner-pupil errors per landmark
