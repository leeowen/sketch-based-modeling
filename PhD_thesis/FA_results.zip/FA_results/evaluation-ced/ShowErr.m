%% displaying CED
load('Allerrs.mat');
Methods = {'SDM','LBP','ERT','Our'};
clr = {'b','m','g','r'};
for t=1:4
errs = Allerrs{t};
x = [0 : 0.001 :0.5];
cumsum = zeros(length(x),1);
nData = size(errs,1);
c = 0;

for thres = x
    
    c = c + 1;
    idx = find(errs <= thres);
    cumsum(c) = length(idx)/nData;
    
end

figure(2);
hold on;
plot( x, cumsum,'Color',clr{t}, 'LineWidth', 2 , 'MarkerEdgeColor','r');

grid on;

axis([0 0.3 0 1]);
hold off;

end
legend(Methods);